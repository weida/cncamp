export INGRESS_HOST=$(kubectl -n istio-system get service istio-ingressgateway -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
export INGRESS_DOMAIN=${INGRESS_HOST}.nip.io

```
$ kubectl -n istio-system delete gateway tracing-gateway
$ kubectl -n istio-system delete virtualservice tracing-vs
$ kubectl -n istio-system delete destinationrule tracing
```

k delete deployment httpserver0-istio -n istiospace
k delete deployment httpserver1-istio -n istiospace
k delete deployment httpserver2-istio -n istiospace

k delete service httpserver-service0  -n istiospace
k delete service httpserver-service1  -n istiospace
k delete service httpserver-service2  -n istiospace

k delete virtualservice httpsserver -n istiospace
k delete gateway httpsserver -n istiospace

kubectl create -f httpserver0-deploy.yaml -n istiospace
kubectl create -f httpserver1-deploy.yaml -n istiospace
kubectl create -f httpserver2-deploy.yaml -n istiospace
